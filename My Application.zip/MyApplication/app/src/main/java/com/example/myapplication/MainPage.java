package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class MainPage extends AppCompatActivity {

    EditText emailSignUp, pwdSignUp, nameSingUp;
    Button signUp;

    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_page);

        nameSingUp = findViewById(R.id.nameSignUp);
        emailSignUp = findViewById(R.id.emailSignUp);
        pwdSignUp = findViewById(R.id.passwordSignUp);
        signUp = findViewById(R.id.signUp);

        firebaseAuth = FirebaseAuth.getInstance();

        signUp.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View v) {
              String email = emailSignUp.getText().toString();
              String pwd = pwdSignUp.getText().toString();
              final String name = nameSingUp.getText().toString();

              if(name.isEmpty()){
                  nameSingUp.setError("Please enter name");
                  nameSingUp.requestFocus();
              }
              if (email.isEmpty()) {
                  emailSignUp.setError("Please enter email");
                  emailSignUp.requestFocus();
              } else if (pwd.isEmpty()) {
                  pwdSignUp.setError("Please enter password");
                  pwdSignUp.requestFocus();
              } else if (email.isEmpty() && pwd.isEmpty() && name.isEmpty()) {
                  Toast.makeText(MainPage.this, "Fields are empty!", Toast.LENGTH_LONG).show();
              } else if (!(email.isEmpty() && pwd.isEmpty())) {
                  firebaseAuth.createUserWithEmailAndPassword(emailSignUp.getText().toString(), pwdSignUp.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                      @Override
                      public void onComplete(@NonNull Task<AuthResult> task) {
                          if (task.isSuccessful()) {
                              Toast.makeText(MainPage.this, "Registered Successfully", Toast.LENGTH_LONG).show();
                              String userID = firebaseAuth.getCurrentUser().getUid();
                              String userCurrency = "1000";

                              DatabaseReference current_user_db = FirebaseDatabase.getInstance().getReference().child("Users").child(userID);

                              Map newPost = new HashMap();
                              newPost.put("name", name);
                              newPost.put("currency", userCurrency);

                              current_user_db.setValue(newPost);

                              Intent toHome = new Intent(MainPage.this, MainActivity.class);
                              startActivity(toHome);
                          } else {
                              Toast.makeText(MainPage.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                          }
                      }
                  });
              } else{
                  Toast.makeText(MainPage.this,"Error Occurred", Toast.LENGTH_LONG).show();
              }
        }

    });

    }
}
