package com.example.myapplication;

import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.AsyncTask;
import android.text.TextUtils;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

class ReverseGeo extends AsyncTask<Location, Void, String> {

    private Context mContext;

//Add a parameter for the onTaskComplete interface that we’ll be creating shortly//

    private OnTaskComplete mListener;

    ReverseGeo(Context applicationContext, OnTaskComplete listener) {
        mListener = listener;
        mContext = applicationContext;

    }
    @Override
    protected void onPostExecute(String address) {
        mListener.onTaskComplete(address);
        super.onPostExecute(address);
    }

    @Override
    protected String doInBackground(Location... params) {
        Geocoder mGeocoder = new Geocoder(mContext,
                Locale.getDefault());

        Location location = params[0];
        List<Address> addresses = null;
        String printAddress = "";

        try {
            addresses = mGeocoder.getFromLocation(
                    location.getLatitude(),
                    location.getLongitude(),
                    1);

        } catch (IOException ioException) {
            printAddress = mContext.getString(R.string.no_address);

        }
        if (addresses.size() == 0) {
            if (printAddress.isEmpty()) {

                printAddress = mContext.getString(R.string.no_address);

            }
        } else {

            Address address = addresses.get(0);
            ArrayList<String> addressList = new ArrayList<>();

            for (int i = 0; i <= address.getMaxAddressLineIndex(); i++) {
                addressList.add(address.getAddressLine(i));
            }

            printAddress = TextUtils.join(
                    ",",
                    addressList);

        }
        return printAddress;
    }
    interface OnTaskComplete {
        void onTaskComplete(String result);
    }
}
