package com.example.myapplication;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Camera;
import android.graphics.Rect;
import android.location.Address;
import android.location.Criteria;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.location.Address;

import java.lang.reflect.Array;
import java.util.ArrayList;
import android.os.AsyncTask;
import android.content.Context;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationListener;


import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.Toast;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.TextView;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.Api;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.StreetViewPanoramaOptions;
import com.google.android.gms.maps.StreetViewPanoramaView;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

public class Maps extends AppCompatActivity implements OnMapReadyCallback,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener, ReverseGeo.OnTaskComplete{

    private GoogleMap mMap;
    private GoogleApiClient googleApiClient;
    private LocationRequest locationRequest;
    private Location lastLocation;
    private Marker currentUserLocationMarker;
    private static final int Request_User_Location_Code = 99;
    private static final int MY_PERMISSIONS_REQUEST_LOCATION = 1;
    private boolean addressRequest;
    private TextView textview, userCurrency;
    private View mTouchOutsideView;
    private OnTouchOutsideViewListener mOnTouchOutsideViewListener;
    private StreetViewPanoramaView mStreetViewPanoramaView;
    private static final String STREETVIEW_BUNDLE_KEY = "StreetViewBundleKey";
    private boolean currencySet;

    private FloatingActionButton fab, fab1, fab2, fab3, current_location_button, profile_back, fabSearch, settings_back, streetInfo, streetView, street_back;
    private Animation fab_open, fab_close, fab_clock, fab_anticlock,fab_open_main;
    private Button buy;
    private LinearLayout profile, settings, streetPopup, streetBack, streetMenu;
    private Geocoder geocoder;
    private TextView mAddressTxtVu;
    private EditText searchBar;
    private FusedLocationProviderClient mFusedLocationClient;
    private LocationCallback mLocationCallback;
    private List<String> addressArray = new ArrayList<>();
    private Map<String, Object> userUpdates = new HashMap<>();
    private Map<String, Object> boughtUpdates = new HashMap<>();
    private Map<String, Object> currencyUpdates = new HashMap<>();



    Boolean isOpen = false;
    Boolean isOpen2 = false;
    Boolean isUp;
    Boolean isUp2;
    FirebaseAuth firebaseAuth;
    FirebaseUser firebaseUser;
    private FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);

        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
            checkUserLocationPermission();
        }
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        textview = findViewById(R.id.textview);

        mFusedLocationClient = LocationServices.getFusedLocationProviderClient(
                this);

        mLocationCallback = new LocationCallback() {
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (addressRequest) {

//Execute ReverseGeo in response to addressRequest//

                    new ReverseGeo(Maps.this, Maps.this)

//Obtain the device's last known location from the FusedLocationProviderClient//

                            .execute(locationResult.getLastLocation());
                }
            }
        };

        fab = findViewById(R.id.fab);
        fab1 =  findViewById(R.id.fab1);
        fab2 =  findViewById(R.id.fab2);
        fab3 =  findViewById(R.id.fab3);
        profile = findViewById(R.id.profile_popup);
        streetMenu = findViewById(R.id.streetMenu);
        profile_back = findViewById(R.id.close_profile);
        fabSearch = findViewById(R.id.fab_search);
        street_back = findViewById(R.id.close_street);
        streetInfo = findViewById(R.id.streetInfo);
        streetView = findViewById(R.id.streetView);
        streetBack = findViewById(R.id.streetPopupBack);
        buy = findViewById(R.id.buyButton);
        userCurrency = findViewById(R.id.userCurrency);
        current_location_button = findViewById(R.id.current_location_button);
        fab_close = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_close);
        fab_open = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open);
        fab_clock = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_rotate_clock);
        fab_anticlock = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_rotate_anticlock);
        fab_open_main = AnimationUtils.loadAnimation(getApplicationContext(), R.anim.fab_open_main);
        isUp = false;
        isUp2 = false;

        firebaseAuth = FirebaseAuth.getInstance();
        String userID = firebaseAuth.getCurrentUser().getUid();

        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference userCurrencySet = db.getReference().child("Users").child(userID);


        userCurrencySet.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                firebaseAuth = FirebaseAuth.getInstance();
                String userID = firebaseAuth.getCurrentUser().getUid();
                String currency = "";
                //List<String> keys = new ArrayList<>();
                if (dataSnapshot.exists()) {
                    if (dataSnapshot.child("currency").exists()) {
                            currency = dataSnapshot.child("currency").getValue(String.class);
                            //Log.d("TAG", currency + "fuck");

                        userCurrency.setText(currency);

                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isOpen) {
                    streetView.startAnimation(fab_close);
                    streetInfo.startAnimation(fab_close);
                    current_location_button.startAnimation(fab_close);
                    fab3.startAnimation(fab_close);
                    fab2.startAnimation(fab_close);
                    fab1.startAnimation(fab_close);
                    fab.startAnimation(fab_anticlock);
                    streetView.setClickable(false);
                    streetInfo.setClickable(false);
                    current_location_button.setClickable(false);
                    fab3.setClickable(false);
                    fab2.setClickable(false);
                    fab1.setClickable(false);
                    isOpen = false;
                    isOpen2 = false;
                } else {
                    streetView.startAnimation(fab_open);
                    streetInfo.startAnimation(fab_open);
                    current_location_button.startAnimation(fab_open);
                    fab3.startAnimation(fab_open);
                    fab2.startAnimation(fab_open);
                    fab1.startAnimation(fab_open);
                    fab.startAnimation(fab_clock);
                    streetView.setClickable(true);
                    streetInfo.setClickable(true);
                    current_location_button.setClickable(true);
                    fab3.setClickable(true);
                    fab2.setClickable(true);
                    fab1.setClickable(true);
                    isOpen = true;
                    isOpen2 = true;
                }
            }
        });

        streetInfo.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View v){
                if(isOpen && !isUp && !isUp2){
                    streetView.startAnimation(fab_close);
                    streetInfo.startAnimation(fab_close);
                    current_location_button.startAnimation(fab_close);
                    fab3.startAnimation(fab_close);
                    fab2.startAnimation(fab_close);
                    fab1.startAnimation(fab_close);
                    fab.startAnimation(fab_close);
                    streetView.setClickable(false);
                    streetInfo.setClickable(false);
                    current_location_button.setClickable(false);
                    fab3.setClickable(false);
                    fab2.setClickable(false);
                    fab1.setClickable(false);
                    fab.setClickable(false);
                    isOpen = false;
                    slideUp(streetMenu);
                    getMyLocation();
                    isUp = true;
                    LatLng cd = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                    String address = getAddress2(cd);
                    textview.setText(address);
                }
          }

            public void slideUp(View view){
                view.setVisibility(View.VISIBLE);
                TranslateAnimation animate = new TranslateAnimation(
                        0,                 // fromXDelta
                        0,                 // toXDelta
                        view.getHeight(),  // fromYDelta
                        0);                // toYDelta
                animate.setDuration(500);
                animate.setFillAfter(true);
                view.startAnimation(animate);
            }

            private void getMyLocation() {
                LatLng latLng = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13));
                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(latLng)      // Sets the center of the map to location user
                        .zoom(20)                   // Sets the zoom
                        .bearing(0)                // Sets the orientation of the camera to east
                        .tilt(90)                   // Sets the tilt of the camera to 30 degrees
                        .build();                   // Creates a CameraPosition from the builder
                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
            }
        });

        street_back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                if(!isOpen && isUp && !isUp2) {
                    slideDown(streetMenu);
                    streetView.startAnimation(fab_open);
                    streetInfo.startAnimation(fab_open);
                    current_location_button.startAnimation(fab_open);
                    fab3.startAnimation(fab_open);
                    fab2.startAnimation(fab_open);
                    fab1.startAnimation(fab_open);
                    fab.startAnimation(fab_open_main);
                    streetView.setClickable(true);
                    streetInfo.setClickable(true);
                    current_location_button.setClickable(true);
                    fab3.setClickable(true);
                    fab2.setClickable(true);
                    fab1.setClickable(true);
                    fab.setClickable(true);
                    isOpen = true;
                    getMyLocation();
                    isUp = false;
                    if (!addressRequest) {
                        getAddress();
                    }
                }
            }

            public void slideDown(View view){
                TranslateAnimation animate = new TranslateAnimation(
                        0,                 // fromXDelta
                        0,                 // toXDelta
                        0,                 // fromYDelta
                        view.getHeight()); // toYDelta
                animate.setDuration(500);
                animate.setFillAfter(true);
                view.startAnimation(animate);
            }

            private void getMyLocation() {
                LatLng latLng = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13));
                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(latLng)      // Sets the center of the map to location user
                        .zoom(17)                   // Sets the zoom
                        .bearing(0)                // Sets the orientation of the camera to east
                        .tilt(0)                   // Sets the tilt of the camera to 30 degrees
                        .build();                   // Creates a CameraPosition from the builder
                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
            }
        });

        fab3.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(Maps.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                //startService(new Intent(Maps.this, MyService.class));
            }
        });

        current_location_button.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                getMyLocation();
            }

            private void getMyLocation() {
                LatLng latLng = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13));
                CameraPosition cameraPosition = new CameraPosition.Builder()
                        .target(latLng)      // Sets the center of the map to location user
                        .zoom(17)                   // Sets the zoom
                        .bearing(0)                // Sets the orientation of the camera to east
                        .tilt(0)                   // Sets the tilt of the camera to 30 degrees
                        .build();                   // Creates a CameraPosition from the builder
                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
            }
        });

        fabSearch.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View v){
                EditText addressField = (EditText) findViewById(R.id.searchBar);
                String address = addressField.getText().toString();

                List<Address> addressList = null;
                MarkerOptions userMarkerOptions = new MarkerOptions();

                if(!TextUtils.isEmpty(address)){
                    Geocoder geocoder = new Geocoder(Maps.this);

                    try {
                        addressList = geocoder.getFromLocationName(address, 6);

                        if(addressList != null){
                            for(int i = 0; i < addressList.size(); i++){
                                Address userAddress = addressList.get(i);
                                LatLng latLng = new LatLng(userAddress.getLatitude(), userAddress.getLongitude());
                                userMarkerOptions.position(latLng);
                                userMarkerOptions.title(address);
                                userMarkerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));

                                //mMap.addMarker((userMarkerOptions));
                                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13));
                                CameraPosition cameraPosition = new CameraPosition.Builder()
                                        .target(latLng)      // Sets the center of the map to location user
                                        .zoom(17)                   // Sets the zoom
                                        .bearing(0)                // Sets the orientation of the camera to east
                                        .tilt(0)                   // Sets the tilt of the camera to 30 degrees
                                        .build();                   // Creates a CameraPosition from the builder
                                mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));
                            }
                        }
                        else{
                            Toast.makeText(Maps.this, "Location not found", Toast.LENGTH_SHORT);
                        }
                    }
                    catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                else{
                    Toast.makeText(Maps.this, "please write any location", Toast.LENGTH_SHORT);
                }
          }
        });

        streetView.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View v){

          }

        });

        fab2.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Maps.this, Settings.class);
                startActivity(intent);
            }
        });

        fab1.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                Intent intent = new Intent(Maps.this, ProfilePage.class);
                startActivity(intent);
            }
        });

        buy.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View v){
              firebaseAuth = FirebaseAuth.getInstance();
              String userID = firebaseAuth.getCurrentUser().getUid();

              LatLng cd = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
              String address = getAddress2(cd);

              //userUpdates.put("Currency", );

              FirebaseDatabase db = FirebaseDatabase.getInstance();
              final DatabaseReference myAddress = db.getReference().child("Users").child(userID);

              myAddress.addValueEventListener(new ValueEventListener() {
                  @Override
                  public void onDataChange(@NonNull DataSnapshot dataSnapshot1) {
                      //addressArray.clear();

                      firebaseAuth = FirebaseAuth.getInstance();
                      String userID = firebaseAuth.getCurrentUser().getUid();
                      LatLng cd = new LatLng(lastLocation.getLatitude(), lastLocation.getLongitude());
                      final String currentAddress = getAddress2(cd);
                      //List<String> keys = new ArrayList<>();
                      if (dataSnapshot1.exists()) {
                          if(!dataSnapshot1.child(currentAddress).exists()){
                              FirebaseDatabase database = FirebaseDatabase.getInstance();
                              DatabaseReference usersRef = database.getReference().child("Users").child(userID).child(currentAddress + "," + userID);
                              final DatabaseReference userCurrencyDB = database.getReference().child("Users").child(userID);
                              DatabaseReference bought = database.getReference().child("Bought");

                              bought.addValueEventListener(new ValueEventListener() {
                                  @Override
                                  public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                      if(dataSnapshot.exists()){
                                          if(!dataSnapshot.child(currentAddress).exists()){
                                              firebaseAuth = FirebaseAuth.getInstance();
                                              String userID = firebaseAuth.getCurrentUser().getUid();
                                              FirebaseDatabase database = FirebaseDatabase.getInstance();
                                              DatabaseReference usersRef = database.getReference().child("Users").child(userID).child(currentAddress);
                                              DatabaseReference bought = database.getReference().child("Bought");
                                              userUpdates.clear();
                                              userUpdates.put("Address", currentAddress);

                                              boughtUpdates.clear();
                                              boughtUpdates.put(currentAddress, userID);

                                              bought.updateChildren(boughtUpdates);
                                              usersRef.updateChildren(userUpdates);

                                              currencySet = true;

                                              Toast.makeText(Maps.this,"Purchase successful" ,Toast.LENGTH_LONG ).show();
                                          }else{
                                              Toast.makeText(Maps.this,"Address Taken!",Toast.LENGTH_LONG ).show();
                                          }
                                      }else{
                                          //Toast.makeText(Maps.this,"Address Taken!",Toast.LENGTH_LONG ).show();
                                      }
                                  }

                                  @Override
                                  public void onCancelled(@NonNull DatabaseError databaseError) {

                                  }
                              });

                          }
                          else{
                              Toast.makeText(Maps.this,"Address Taken!",Toast.LENGTH_LONG ).show();
                          }

                          if(currencySet){
                              String currencySave ;
                              if (dataSnapshot1.child("currency").exists()) {
                                  currencySave = dataSnapshot1.child("currency").getValue(String.class);
                                  int currencyP = Integer.parseInt(currencySave);
                                  currencyP = currencyP - 100;
                                  String currencyStringO = Integer.toString(currencyP);

                                  myAddress.child("currency").setValue(currencyStringO);
                                  currencySet = false;
                              }

                          }
                      }
                  }
                  @Override
                  public void onCancelled(@NonNull DatabaseError databaseError) {

                  }
              });

              //Toast.makeText(Maps.this,address, Toast.LENGTH_LONG).show();
          }
        });



    }

    private String getAddress1(LatLng myCoordinates){
        String myAddress = "";
        Geocoder geo = new Geocoder(Maps.this, Locale.getDefault());
        try {
            List<Address> addresses = geo.getFromLocation(myCoordinates.latitude, myCoordinates.longitude, 1);
            String address  = addresses.get(0).getAddressLine(0);
            myAddress = addresses.get(0).getLocality();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return myAddress;
    }


    public String getAddress2(LatLng myCoordinates) {
        String myAddress = "";
        Geocoder gc = new Geocoder(this, Locale.ENGLISH);
        try {
            List<Address> addresses = gc.getFromLocation(myCoordinates.latitude, myCoordinates.longitude, 1);
            StringBuilder sb = new StringBuilder();
            if (addresses.size() > 0) {
                Address address = addresses.get(0);
                //for (int i = 0; i < address.getMaxAddressLineIndex(); i++)
                    sb.append(address.getAddressLine(0));
                //sb.append(address.getPremises()).append(" ");

                myAddress = sb.toString();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return myAddress;
    }


        /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;


        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            buildGoogleApiClient();
            mMap.setMyLocationEnabled(true);
            mMap.getUiSettings().setMyLocationButtonEnabled(false);
            mMap.getUiSettings().setCompassEnabled(false);
        }

    }


    public boolean checkUserLocationPermission(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED){
            if(ActivityCompat.shouldShowRequestPermissionRationale(this,Manifest.permission.ACCESS_FINE_LOCATION)){
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, Request_User_Location_Code);
            }
            else{
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, Request_User_Location_Code);
            }
            return false;
        }
        else{
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        switch (requestCode){
            case Request_User_Location_Code:
                if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                    if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
                        if(googleApiClient == null){
                            buildGoogleApiClient();
                        }
                        mMap.setMyLocationEnabled(true);
                    }
                }
                else{
                    Toast.makeText(this,"permission denided...", Toast.LENGTH_SHORT);
                }
            case MY_PERMISSIONS_REQUEST_LOCATION:
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

//If the permission request has been granted, then call getAddress//

                    getAddress();
                } else {
                    Toast.makeText(this,
                            R.string.location_permission_denied,
                            Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }

    protected synchronized void buildGoogleApiClient(){
        googleApiClient = new GoogleApiClient.Builder(this).addConnectionCallbacks(this).addOnConnectionFailedListener(this).addApi(LocationServices.API).build();

        googleApiClient.connect();
    }

    @Override
    public void onLocationChanged(Location location) {
        lastLocation = location;

        if(currentUserLocationMarker != null){
            currentUserLocationMarker.remove();
        }

        LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());

        /*MarkerOptions markerOptions = new MarkerOptions();
        markerOptions.position(latLng);
        markerOptions.title("You");
        markerOptions.icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED));

        currentUserLocationMarker = mMap.addMarker(markerOptions);*/


        mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 13));
        CameraPosition cameraPosition = new CameraPosition.Builder()
                .target(latLng)      // Sets the center of the map to location user
                .zoom(17)                   // Sets the zoom
                .bearing(90)                // Sets the orientation of the camera to east
                .tilt(40)                   // Sets the tilt of the camera to 30 degrees
                .build();                   // Creates a CameraPosition from the builder
        mMap.animateCamera(CameraUpdateFactory.newCameraPosition(cameraPosition));

        if(googleApiClient != null){
            LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, this);
        }

        firebaseAuth = FirebaseAuth.getInstance();
        String userID = firebaseAuth.getCurrentUser().getUid();

        String userAddress = getAddress2(latLng);

        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference myAddress = db.getReference().child("Users").child(userID);
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        locationRequest = new LocationRequest();
        locationRequest.setInterval(1100);
        locationRequest.setFastestInterval(1100);
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);

        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {

            LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, this);
        }
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    private void getAddress(){
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]
                            {Manifest.permission.ACCESS_FINE_LOCATION},
                    MY_PERMISSIONS_REQUEST_LOCATION);
        } else {
            addressRequest = true;

//Request location updates//

            mFusedLocationClient.requestLocationUpdates
                    (getLocationRequest(),
                            mLocationCallback,
                            null);

            textview.setText(getString(R.string.address_text));

        }
    }

    private LocationRequest getLocationRequest(){
        LocationRequest locationRequest = new LocationRequest();

//Specify how often the app should receive location updates, in milliseconds//

        locationRequest.setInterval(10000);
        return locationRequest;
    }

    @Override
    public void onTaskComplete(String result) {
        if (addressRequest) {

//Update the TextView with the reverse geocoded address//

            textview.setText(getString(R.string.address_text,
                    result));
        }
    }

    public void setOnTouchOutsideViewListener(View view, OnTouchOutsideViewListener onTouchOutsideViewListener) {
        mTouchOutsideView = view;
        mOnTouchOutsideViewListener = onTouchOutsideViewListener;
    }

    public OnTouchOutsideViewListener getOnTouchOutsideViewListener() {
        return mOnTouchOutsideViewListener;
    }

    @Override
    public boolean dispatchTouchEvent(final MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            // Notify touch outside listener if user tapped outside a given view
            if (mOnTouchOutsideViewListener != null && mTouchOutsideView != null
                    && mTouchOutsideView.getVisibility() == View.VISIBLE) {
                Rect viewRect = new Rect();
                mTouchOutsideView.getGlobalVisibleRect(viewRect);
                if (!viewRect.contains((int) ev.getRawX(), (int) ev.getRawY())) {
                    mOnTouchOutsideViewListener.onTouchOutside(mTouchOutsideView, ev);
                }
            }
        }
        return super.dispatchTouchEvent(ev);
    }

    public interface OnTouchOutsideViewListener {
        public void onTouchOutside(View view, MotionEvent event);
    }




}
