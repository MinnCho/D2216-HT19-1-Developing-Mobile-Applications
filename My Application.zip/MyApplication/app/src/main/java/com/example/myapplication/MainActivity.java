package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityManager;
import android.app.Application;
import android.content.ComponentCallbacks2;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.Iterator;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    Button toSignUp, signIn;
    EditText email, pwd;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        startService(new Intent(this, MyService.class));

        startService(new Intent(getBaseContext(), AppStopped.class));

        toSignUp = findViewById(R.id.signUpButton);
        signIn = findViewById(R.id.signInBtn);
        email = findViewById(R.id.emailInput);
        pwd = findViewById(R.id.passwordInput);

        final FirebaseAuth firebaseAuth;

        toSignUp.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View v){
              Intent intToSignUp = new Intent(MainActivity.this, MainPage.class);
              startActivity(intToSignUp);
          }
        });

        firebaseAuth = FirebaseAuth.getInstance();

        signIn.setOnClickListener(new View.OnClickListener(){
          @Override
          public void onClick(View v){
              String emailIn = email.getText().toString();
              String pwdIn = pwd.getText().toString();

              if (emailIn.isEmpty()) {
                  email.setError("Please enter email");
                  email.requestFocus();
              } else if (pwdIn.isEmpty()) {
                  pwd.setError("Please enter password");
                  pwd.requestFocus();
              } else if (emailIn.isEmpty() && pwdIn.isEmpty()) {
                  Toast.makeText(MainActivity.this, "Fields are empty!", Toast.LENGTH_LONG).show();
              }else if (!(emailIn.isEmpty() && pwdIn.isEmpty())) {
                  firebaseAuth.signInWithEmailAndPassword(email.getText().toString(), pwd.getText().toString()).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                      @Override
                      public void onComplete(@NonNull Task<AuthResult> task) {
                          if (task.isSuccessful()) {
                              startActivity(new Intent(MainActivity.this, Maps.class));
                              stopService(new Intent(MainActivity.this, MyService.class));
                          } else {
                              Toast.makeText(MainActivity.this, task.getException().getMessage(), Toast.LENGTH_LONG).show();
                          }
                      }
                  });
              }else{
                  Toast.makeText(MainActivity.this,"Error Occurred", Toast.LENGTH_LONG).show();
              }
          }
        });

    }
}


