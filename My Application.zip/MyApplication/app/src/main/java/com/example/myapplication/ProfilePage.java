package com.example.myapplication;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceFragmentCompat;
import android.widget.TextView;
import com.example.myapplication.MainActivity;
import android.view.View;

import java.io.IOException;
import java.util.List;
import java.util.Locale;
import java.util.zip.Inflater;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;


public class ProfilePage extends AppCompatActivity {

    TextView proname, currencyProfile;
    FirebaseAuth firebaseAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.profile_main);

        FirebaseAuth Firebaseauth = FirebaseAuth.getInstance();
        FirebaseUser firebaseuser = Firebaseauth.getCurrentUser();
       // String email = firebaseuser.getEmail();
        proname = findViewById(R.id.profileName);
        currencyProfile = findViewById(R.id.currencyProfile);
        //proname.append("OKAY");

        firebaseAuth = FirebaseAuth.getInstance();
        String userID = firebaseAuth.getCurrentUser().getUid();

        FirebaseDatabase db = FirebaseDatabase.getInstance();
        DatabaseReference userCurrencySet = db.getReference().child("Users").child(userID);


        userCurrencySet.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                firebaseAuth = FirebaseAuth.getInstance();
                String userID = firebaseAuth.getCurrentUser().getUid();
                String currency = "";
                String name ="";
                //List<String> keys = new ArrayList<>();
                if (dataSnapshot.exists()) {
                    if (dataSnapshot.child("currency").exists() && dataSnapshot.child("name").exists()) {
                        currency = dataSnapshot.child("currency").getValue(String.class);
                        name = dataSnapshot.child("name").getValue(String.class);
                        //Log.d("TAG", currency + "fuck");

                        currencyProfile.setText(currency);
                        proname.setText(name);

                    }
                }
            }
            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }
    }

